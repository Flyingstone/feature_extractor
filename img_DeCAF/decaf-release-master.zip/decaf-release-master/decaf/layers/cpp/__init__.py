"""Imports the cpp wrapper functions."""

# pylint: disable=W0401
from decaf.layers.cpp.wrapper import *
