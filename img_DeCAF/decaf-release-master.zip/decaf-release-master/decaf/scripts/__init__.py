"""This folder implements the interface to get DecafNet - the network that
Jeff trained using the modified cuda convnet code.
"""
